const audioPlayer = document.getElementById('audioPlayer');
const fileInput = document.getElementById('fileInput');
const addTracksButton = document.getElementById('addTracks');
const playButton = document.getElementById('play');
const prevButton = document.getElementById('prev');
const nextButton = document.getElementById('next');
const volumeControl = document.getElementById('volumeControl');
const trackInfo = document.getElementById('trackInfo');
const playlistElement = document.getElementById('playlistItems');
const themeSwitch = document.getElementById('themeSwitch');
const progressBar = document.getElementById('progressBar');
const controls = document.getElementById('controls');
const progressContainer = document.getElementById('progressContainer');
const player = document.getElementById('player');
const menu = document.getElementById('menu');
const menuButton = document.getElementById('menuButton');
const overlay = document.getElementById('overlay');
const volumePercentage = document.getElementById('volumePercentage');
const togglePlaylistLink = document.getElementById('togglePlaylist');
const playlist = document.getElementById('playlist');
const currentTimeDisplay = document.getElementById('currentTime');
const durationDisplay = document.getElementById('duration');
const body = document.body;
const spectrumCanvas = document.getElementById('spectrumCanvas');
const visualizationSelect = document.getElementById('visualizationSelect');
const canvasContext = spectrumCanvas.getContext('2d');
const splashScreen = document.getElementById('splashScreen');

let currentTrackIndex = 0;
let tracks = [];
let playlistVisible = false;
let audioContext, analyser, source, controlsTimeout;

window.addEventListener('load', () => {
    setTimeout(() => {
        splashScreen.style.display = 'none';
    }, 5000);
});

addTracksButton.addEventListener('click', () => {
    fileInput.click();
});

fileInput.addEventListener('change', (event) => {
    tracks = [...event.target.files];
    updatePlaylist();
    if (tracks.length > 0) {
        loadTrack(0);
    }
});

playButton.addEventListener('click', () => {
    if (audioPlayer.paused) {
        audioPlayer.play();
        playButton.textContent = 'Pause';
        startVisualization();
    } else {
        audioPlayer.pause();
        playButton.textContent = 'Play';
    }
});

prevButton.addEventListener('click', () => {
    if (tracks.length > 0) {
        currentTrackIndex = (currentTrackIndex - 1 + tracks.length) % tracks.length;
        loadTrack(currentTrackIndex);
        audioPlayer.play();
        playButton.textContent = 'Pause';
        showPlaylist();
        startVisualization();
    }
});

nextButton.addEventListener('click', () => {
    if (tracks.length > 0) {
        currentTrackIndex = (currentTrackIndex + 1) % tracks.length;
        loadTrack(currentTrackIndex);
        audioPlayer.play();
        playButton.textContent = 'Pause';
        showPlaylist();
        startVisualization();
    }
});

volumeControl.addEventListener('input', (event) => {
    audioPlayer.volume = event.target.value;
    volumePercentage.textContent = `${Math.round(event.target.value * 100)}%`;
});

themeSwitch.addEventListener('change', (event) => {
    if (event.target.checked) {
        body.classList.remove('dark-mode');
        body.classList.add('light-mode');
    } else {
        body.classList.remove('light-mode');
        body.classList.add('dark-mode');
    }
});

audioPlayer.addEventListener('timeupdate', () => {
    if (audioPlayer.duration) {
        progressBar.max = audioPlayer.duration;
        progressBar.value = audioPlayer.currentTime;
        currentTimeDisplay.textContent = formatTime(audioPlayer.currentTime);
        durationDisplay.textContent = formatTime(audioPlayer.duration);
    }
});

progressBar.addEventListener('input', () => {
    audioPlayer.currentTime = progressBar.value;
});

function loadTrack(index) {
    const track = tracks[index];
    const url = URL.createObjectURL(track);
    audioPlayer.src = url;
    trackInfo.textContent = `Playing: ${track.name}`;
    audioPlayer.load();
}

function updatePlaylist() {
    playlistElement.innerHTML = '';
    tracks.forEach((track, index) => {
        const li = document.createElement('li');
        li.textContent = `${index + 1} - ${track.name}`;
        li.addEventListener('click', () => {
            currentTrackIndex = index;
            loadTrack(currentTrackIndex);
            audioPlayer.play();
            playButton.textContent = 'Pause';
            showPlaylist();
            startVisualization();
        });
        playlistElement.appendChild(li);
    });
}

audioPlayer.addEventListener('ended', () => {
    nextButton.click();
});

player.addEventListener('mousemove', () => {
    showControls();
    if (controlsTimeout) {
        clearTimeout(controlsTimeout);
    }
    controlsTimeout = setTimeout(hideControls, 2000);
});

function showControls() {
    controls.style.opacity = 1;
    progressContainer.style.opacity = 1;
}

function hideControls() {
    controls.style.opacity = 0;
    progressContainer.style.opacity = 0;
}

menuButton.addEventListener('click', () => {
    menu.style.left = '0';
    overlay.classList.add('show');
});

overlay.addEventListener('click', () => {
    menu.style.left = '-250px';
    overlay.classList.remove('show');
});

togglePlaylistLink.addEventListener('click', () => {
    playlistVisible = !playlistVisible;
    if (playlistVisible) {
        playlist.style.display = 'block';
    } else {
        playlist.style.display = 'none';
    }
    menu.style.left = '-250px';
    overlay.classList.remove('show');
});

function showPlaylist() {
    if (!playlistVisible) {
        playlist.style.display = 'block';
    }
}

audioPlayer.addEventListener('play', showPlaylist);
audioPlayer.addEventListener('pause', () => {
    if (!playlistVisible) {
        playlist.style.display = 'none';
    }
});

function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
}

function startVisualization() {
    if (!audioContext) {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        analyser = audioContext.createAnalyser();
        source = audioContext.createMediaElementSource(audioPlayer);
        source.connect(analyser);
        analyser.connect(audioContext.destination);
    }

    analyser.fftSize = 256;
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    function draw() {
        requestAnimationFrame(draw);
        analyser.getByteFrequencyData(dataArray);
        canvasContext.clearRect(0, 0, spectrumCanvas.width, spectrumCanvas.height);

        const visualizationType = visualizationSelect.value;
        switch (visualizationType) {
            case 'bars':
                drawBars(dataArray, bufferLength);
                break;
            case 'waves':
                drawWaves(dataArray, bufferLength);
                break;
            case 'circles':
                drawCircles(dataArray, bufferLength);
                break;
            default:
                drawBars(dataArray, bufferLength);
        }
    }

    draw();
}

function drawBars(dataArray, bufferLength) {
    const barWidth = (spectrumCanvas.width / bufferLength) * 2.5;
    let barHeight;
    let x = 0;

    for (let i = 0; i < bufferLength; i++) {
        barHeight = dataArray[i];
        canvasContext.fillStyle = `rgb(${barHeight + 100}, 50, 50)`;
        canvasContext.fillRect(x, spectrumCanvas.height - barHeight / 2, barWidth, barHeight / 2);
        x += barWidth + 1;
    }
}

function drawWaves(dataArray, bufferLength) {
    canvasContext.beginPath();
    canvasContext.moveTo(0, spectrumCanvas.height / 2);

    for (let i = 0; i < bufferLength; i++) {
        const y = (dataArray[i] / 255.0) * spectrumCanvas.height;
        canvasContext.lineTo((i / bufferLength) * spectrumCanvas.width, spectrumCanvas.height - y);
    }

    canvasContext.lineTo(spectrumCanvas.width, spectrumCanvas.height / 2);
    canvasContext.stroke();
}

function drawCircles(dataArray, bufferLength) {
    const radius = Math.min(spectrumCanvas.width, spectrumCanvas.height) / 4;
    const centerX = spectrumCanvas.width / 2;
    const centerY = spectrumCanvas.height / 2;

    for (let i = 0; i < bufferLength; i++) {
        const angle = (i / bufferLength) * 2 * Math.PI;
        const barHeight = dataArray[i];
        const x = centerX + Math.cos(angle) * radius;
        const y = centerY + Math.sin(angle) * radius;

        canvasContext.beginPath();
        canvasContext.moveTo(centerX, centerY);
        canvasContext.lineTo(x, y);
        canvasContext.strokeStyle = `rgb(${barHeight + 100}, 50, 50)`;
        canvasContext.stroke();
    }
}
